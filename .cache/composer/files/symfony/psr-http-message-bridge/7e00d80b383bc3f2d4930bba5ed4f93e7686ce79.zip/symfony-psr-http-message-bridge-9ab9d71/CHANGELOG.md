CHANGELOG
=========

* 1.1.0 (2018-08-30)

  * Added support for creating PSR-7 messages using PSR-17 factories

* 1.0.2 (2017-12-19)

  * Fixed request target in PSR7 Request (mtibben)

* 1.0.1 (2017-12-04)

  * Added support for Symfony 4 (dunglas)

* 1.0.0 (2016-09-14)

  * Initial release
